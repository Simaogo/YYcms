<?php

namespace app\admin\model;

class Channeltype extends \think\Model{
    
}
