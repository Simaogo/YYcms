<?php

namespace app\admin\controller;

class Diyforms extends \app\common\controller\Backend{
    public function index(){
        
    }
}
