<?php
namespace app\common\model;
class Diyforms extends \think\Model{
    
}
