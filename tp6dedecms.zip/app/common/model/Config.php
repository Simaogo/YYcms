<?php

namespace app\common\model;
class Config extends \think\Model{
    protected $name = 'sysconfig';
    protected static function init()
    {
        
    }
}
