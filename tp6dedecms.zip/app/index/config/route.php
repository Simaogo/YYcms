<?php
use think\facade\Route;
Route::rule('admin/china2020','admin/login/index','*');