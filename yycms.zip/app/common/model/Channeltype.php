<?php

namespace app\common\model;

class Channeltype extends \think\Model{
    
}
