<?php

namespace app\common\model;

class Uploads extends \think\model{

}
