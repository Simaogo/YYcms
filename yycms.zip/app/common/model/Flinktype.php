<?php
namespace app\common\model;
class Flinktype extends \think\model{
    
}
