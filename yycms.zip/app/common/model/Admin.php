<?php
namespace app\admin\model;
class Admin extends \think\Model{
    protected $table = '';
    protected static function init()
    {
        
    }
}
