<?php
namespace fun;
class Process{
    
   /**
    * 列表转成可存储的值
    * @param type $data 
    * @param type $name 解析字段
    * @return type 
    */
    public static function encode_list($data,$name='form_data'){
       if($data){
           foreach ($data as $key=>$val){
               $data[$key]= serialize($val[$name]);
           }
       } 
       return $data;
    }
    /**
     * 单个转成可存储的值
     * @param type $data
     * @param type $name
     * @return type
     */
    public static function encode_item($data){
        return serialize($data);
    }
    /**
     * 列表转成数组
     * @param type $data
     * @param type $type
     * @param type $name
     * @return type array
     */
    public static function decode_list($data,$type=0,$name='form_data'){
        if($data){
            foreach ($data as $key=>$val){
                if($val[$name]){
                    $arr=unserialize($val[$name]);
                    if(!$arr){
                        $temp = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $val[$name]);
                        if($type==0){
                            $data[$key][$name]= unserialize($temp);
                        } else {
                            $data[$key]= array_merge($data[$key],$temp);
                        }
                    } else {
                        if($type==0){
                            $data[$key][$name]=$arr;
                        } else {
                             $data[$key]= array_merge($data[$key],$arr);
                        }
                        
                    }
                }
            }
        }
        return $data;
    }
    /**
     * 单个转成数组
     * @param type $data
     * @param type $name
     * @return type
     */
    public static function decode_item($data){
        if(!$data) return '';
        $arr=@unserialize($data);
        if(!$arr) {
             $temp = preg_replace('!s:(\d+):"(.*?)";!se', "'s:'.strlen('$2').':\"$2\";'", $data);
             if($temp) return unserialize($temp);
             return $data;
        }
        return $arr;
    }
    /*
     * 格式化二维数组
     * 
     */
    public static function formatarr($data){
        foreach ($data as $key=>$val){
            if(is_array($val)){
                $data[$key]= self::encode_item($val);
            }
        }
        return $data;
    }
    public function getsex($sex){
        if($sex==1) return '男';
        if($sex==2) return '女';
    }
    
    /**
     * 解析图集字段为字符串
     * @param type $fielsetstr
     * @return array
     */
    public static function decode_imgurls($str){
        $pattern = "/ddimg='(.*)'\s+text/";
        if(preg_match($pattern, $str)){
            preg_match_all($pattern, $str,$imgurls);//解析图集字段
            return $imgurls[1];
        } else {
            return $str;
        }
    }
    /**
     *  从内容提取描述
     * @param type $html
     * @param type $len
     * @return string
     */
    public static function  getplaintextintrofromhtml($html,$len=150) {
            if(!$html) return '';
            $html = strip_tags($html);
            $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
            $html_len = mb_strlen($html,'UTF-8');
            $html = mb_substr($html, 0, $len, 'UTF-8');
            return $html;
    }
}